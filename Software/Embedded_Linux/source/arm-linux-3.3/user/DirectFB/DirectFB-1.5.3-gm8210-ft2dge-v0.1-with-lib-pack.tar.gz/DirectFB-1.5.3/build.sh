#!/bin/bash

##### Please modify these variable to match your environment first #####

## 1. The path where you put the tool-chain of GM8210
toolchain_path=/usr/src/GM8210/arm-linux-3.3/toolchain_gnueabi-4.4.0_ARMv5TE

## 2. The path where you put the required third-party library ex: zlib, freetype, libjpeg, libpng..etc
third_party_path=/usr/src/GM8210

##### Modify END #####


export PATH=$toolchain_path/usr/bin:$PATH
LDFLAGS="-L$third_party_path/lib"
CFLAGS="-I$third_party_path/include"
PKG_CONFIG_PATH="$third_party_path/lib/pkgconfig"

export LDFLAGS
export CFLAGS
export PKG_CONFIG_PATH

cp -R ./thirdparty/lib $third_party_path/

./configure --build=i686-linux --host=arm-unknown-linux-uclibcgnueabi --disable-multi \
--prefix=$third_party_path --disable-static --enable-shared \
--disable-osx --disable-x11 --disable-voodoo --disable-mmx --disable-sse \
--enable-fbdev --disable-vnc --enable-jpeg --enable-zlib --enable-png \
--enable-gif --enable-freetype --disable-linotype --enable-video4linux \
--disable-video4linux2 --with-tests --without-tools \
--with-inputdrivers=linuxinput,ps2mouse,keyboard \
--disable-debug --disable-debug-support \
--with-gfxdrivers=ft2dge

make

make install
