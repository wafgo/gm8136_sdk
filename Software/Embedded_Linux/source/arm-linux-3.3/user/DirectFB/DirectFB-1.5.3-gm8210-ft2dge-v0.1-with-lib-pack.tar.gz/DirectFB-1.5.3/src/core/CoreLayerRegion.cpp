/*
   (c) Copyright 2001-2011  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjälä <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/

#include <config.h>

#include "CoreLayerRegion.h"

extern "C" {
#include <directfb_util.h>

#include <direct/debug.h>
#include <direct/mem.h>
#include <direct/memcpy.h>
#include <direct/messages.h>

#include <fusion/conf.h>

#include <core/core.h>
}

D_DEBUG_DOMAIN( DirectFB_CoreLayerRegion, "DirectFB/CoreLayerRegion", "DirectFB CoreLayerRegion" );

/*********************************************************************************************************************/

DFBResult
CoreLayerRegion_FlipUpdate(
                    CoreLayerRegion                           *obj,
                    const DFBRegion                           *update,
                    DFBSurfaceFlipFlags                        flags
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ILayerRegion_Real real( core_dfb, obj );

        return real.FlipUpdate( update, flags );
    }

    DirectFB::ILayerRegion_Requestor requestor( core_dfb, obj );

    return requestor.FlipUpdate( update, flags );
}

DFBResult
CoreLayerRegion_GetSurface(
                    CoreLayerRegion                           *obj,
                    CoreSurface                              **ret_surface
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ILayerRegion_Real real( core_dfb, obj );

        return real.GetSurface( ret_surface );
    }

    DirectFB::ILayerRegion_Requestor requestor( core_dfb, obj );

    return requestor.GetSurface( ret_surface );
}

/*********************************************************************************************************************/

static FusionCallHandlerResult
CoreLayerRegion_Dispatch( int           caller,   /* fusion id of the caller */
                     int           call_arg, /* optional call parameter */
                     void         *ptr, /* optional call parameter */
                     unsigned int  length,
                     void         *ctx,      /* optional handler context */
                     unsigned int  serial,
                     void         *ret_ptr,
                     unsigned int  ret_size,
                     unsigned int *ret_length )
{
    DirectFB::CoreLayerRegionDispatch *dispatch = (DirectFB::CoreLayerRegionDispatch*) ctx;

    dispatch->Dispatch( caller, call_arg, ptr, length, ret_ptr, ret_size, ret_length );

    return FCHR_RETURN;
}

void *CoreLayerRegion_Init_Dispatch(
                    CoreDFB              *core,
                    CoreLayerRegion      *obj,
                    FusionCall           *call
)
{
    DirectFB::CoreLayerRegionDispatch *dispatch = new DirectFB::CoreLayerRegionDispatch( core, new DirectFB::ILayerRegion_Real(core, obj) );

    fusion_call_init3( call, CoreLayerRegion_Dispatch, dispatch, core->world );

    return dispatch;
}

void  CoreLayerRegion_Deinit_Dispatch(
                    void                 *_dispatch
)
{
    DirectFB::CoreLayerRegionDispatch *dispatch = (DirectFB::CoreLayerRegionDispatch*) _dispatch;

    delete dispatch;
}

/*********************************************************************************************************************/

namespace DirectFB {



DFBResult
ILayerRegion_Requestor::FlipUpdate(
                    const DFBRegion                           *update,
                    DFBSurfaceFlipFlags                        flags
)
{
    DFBResult           ret;
    CoreLayerRegionFlipUpdate       *block = (CoreLayerRegionFlipUpdate*) alloca( sizeof(CoreLayerRegionFlipUpdate) );
    CoreLayerRegionFlipUpdateReturn  return_block;

    D_DEBUG_AT( DirectFB_CoreLayerRegion, "ILayerRegion_Requestor::%s()\n", __FUNCTION__ );


  if (update) {
    block->update = *update;
    block->update_set = true;
  }
  else
    block->update_set = false;
    block->flags = flags;

    ret = (DFBResult) CoreLayerRegion_Call( obj, FCEF_NONE, CoreLayerRegion_FlipUpdate, block, sizeof(CoreLayerRegionFlipUpdate), &return_block, sizeof(return_block), NULL );
    if (ret) {
        D_DERROR( ret, "%s: CoreLayerRegion_Call( CoreLayerRegion_FlipUpdate ) failed!\n", __FUNCTION__ );
        return ret;
    }

    if (return_block.result) {
         D_DERROR( return_block.result, "%s: CoreLayerRegion_FlipUpdate failed!\n", __FUNCTION__ );
         return return_block.result;
    }


    return DFB_OK;
}


DFBResult
ILayerRegion_Requestor::GetSurface(
                    CoreSurface                              **ret_surface
)
{
    DFBResult           ret;
    CoreSurface *surface = NULL;
    CoreLayerRegionGetSurface       *block = (CoreLayerRegionGetSurface*) alloca( sizeof(CoreLayerRegionGetSurface) );
    CoreLayerRegionGetSurfaceReturn  return_block;

    D_DEBUG_AT( DirectFB_CoreLayerRegion, "ILayerRegion_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( ret_surface != NULL );


    ret = (DFBResult) CoreLayerRegion_Call( obj, FCEF_NONE, CoreLayerRegion_GetSurface, block, sizeof(CoreLayerRegionGetSurface), &return_block, sizeof(return_block), NULL );
    if (ret) {
        D_DERROR( ret, "%s: CoreLayerRegion_Call( CoreLayerRegion_GetSurface ) failed!\n", __FUNCTION__ );
        return ret;
    }

    if (return_block.result) {
         D_DERROR( return_block.result, "%s: CoreLayerRegion_GetSurface failed!\n", __FUNCTION__ );
         return return_block.result;
    }


    ret = (DFBResult) CoreSurface_Catch( core, return_block.surface_id, &surface );
    if (ret) {
         D_DERROR( ret, "%s: Catching surface by ID %u failed!\n", __FUNCTION__, return_block.surface_id );
         return ret;
    }

    *ret_surface = surface;

    return DFB_OK;
}

/*********************************************************************************************************************/

DFBResult
CoreLayerRegionDispatch::Dispatch( FusionID      caller,
                                int           method,
                                void         *ptr,
                                unsigned int  length,
                                void         *ret_ptr,
                                unsigned int  ret_size,
                                unsigned int *ret_length )
{
    D_UNUSED
    DFBResult ret;

    D_DEBUG_AT( DirectFB_CoreLayerRegion, "CoreLayerRegionDispatch::%s()\n", __FUNCTION__ );

    switch (method) {
        case CoreLayerRegion_FlipUpdate: {
            D_UNUSED
            CoreLayerRegionFlipUpdate       *args        = (CoreLayerRegionFlipUpdate *) ptr;
            CoreLayerRegionFlipUpdateReturn *return_args = (CoreLayerRegionFlipUpdateReturn *) ret_ptr;

            D_DEBUG_AT( DirectFB_CoreLayerRegion, "=-> CoreLayerRegion_FlipUpdate\n" );

            return_args->result = real->FlipUpdate( args->update_set ? &args->update : NULL, args->flags );
            if (return_args->result == DFB_OK) {
            }

            *ret_length = sizeof(CoreLayerRegionFlipUpdateReturn);

            return DFB_OK;
        }

        case CoreLayerRegion_GetSurface: {
    CoreSurface *surface = NULL;
            D_UNUSED
            CoreLayerRegionGetSurface       *args        = (CoreLayerRegionGetSurface *) ptr;
            CoreLayerRegionGetSurfaceReturn *return_args = (CoreLayerRegionGetSurfaceReturn *) ret_ptr;

            D_DEBUG_AT( DirectFB_CoreLayerRegion, "=-> CoreLayerRegion_GetSurface\n" );

            return_args->result = real->GetSurface( &surface );
            if (return_args->result == DFB_OK) {
                CoreSurface_Throw( surface, caller, &return_args->surface_id );
            }

            *ret_length = sizeof(CoreLayerRegionGetSurfaceReturn);

            return DFB_OK;
        }

    }

    return DFB_NOSUCHMETHOD;
}

}
