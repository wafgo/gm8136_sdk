/*
   (c) Copyright 2008  Denis Oliver Kropp

   All rights reserved.

   This file is subject to the terms and conditions of the MIT License:

   Permission is hereby granted, free of charge, to any person
   obtaining a copy of this software and associated documentation
   files (the "Software"), to deal in the Software without restriction,
   including without limitation the rights to use, copy, modify, merge,
   publish, distribute, sublicense, and/or sell copies of the Software,
   and to permit persons to whom the Software is furnished to do so,
   subject to the following conditions:

   The above copyright notice and this permission notice shall be
   included in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include  <linux/fb.h> 

#include <direct/messages.h>

#include <directfb.h>
#include <directfb_strings.h>
#include <directfb_util.h>

#define  DIRECTFB_VERSION  "1.7.1"
#define  FRAMEBUFFER_DEV0 "/dev/fb0"
#define  FRAMEBUFFER_DEV1 "/dev/fb1"
#define  DBGMSGON  1

int gLoopNum;

int main( int argc, char *argv[] )
{
     
     DFBResult               ret;
     int                     i;
     DFBSurfaceDescription   descImg;
     IDirectFB              *dfb;
     
     IDirectFBSurface       *dest= NULL;
     DFBSurfaceDescription  dsc;
     
     //DFBSurfacePixelFormat   dest_format   = DSPF_UNKNOWN;
     struct timeval tv, tv2;
     
     int win_w, win_h;
     
     /* Check FrameBuffer Infomation */
     int gFB;
     int fbi;
     int screen_max_w = 0;
     int screen_max_h = 0;
     struct fb_var_screeninfo  gFBInfo;
     struct fb_fix_screeninfo  fix;
     
     
     gFB = open( FRAMEBUFFER_DEV0, O_RDWR );
     if ( gFB >= 0 )  {
        fbi = ioctl( gFB, FBIOGET_VSCREENINFO, &gFBInfo );
        if (fbi >= 0) {
           screen_max_w = (gFBInfo.xres >= screen_max_w)?(gFBInfo.xres):(screen_max_w);
           screen_max_h = (gFBInfo.yres >= screen_max_h)?(gFBInfo.yres):(screen_max_h);
        }
     }
     
     if (ioctl( gFB, FBIOGET_FSCREENINFO, &fix ) >= 0) {
        #if (DBGMSGON)
        printf("============= check fb0 ============\n");
        printf("[frame buffer] fix.smem_start is 0x%08lx\n", fix.smem_start );
        printf("[frame buffer] fix.smem_len   is %d\n", fix.smem_len );
        printf("[frame buffer] fix.mmio_start is 0x%08lx\n", fix.mmio_start );
        printf("[frame buffer] fix.mmio_len   is %d\n", fix.mmio_len );
        #endif
     }
     close(gFB);
     
     gFB = open( FRAMEBUFFER_DEV1, O_RDWR );
     if (ioctl( gFB, FBIOGET_FSCREENINFO, &fix ) >= 0) {
        #if (DBGMSGON)
        printf("============= check fb1 ============\n");
        printf("[frame buffer] fix.smem_start is 0x%08lx\n", fix.smem_start );
        printf("[frame buffer] fix.smem_len   is %d\n", fix.smem_len );
        printf("[frame buffer] fix.mmio_start is 0x%08lx\n", fix.mmio_start );
        printf("[frame buffer] fix.mmio_len   is %d\n", fix.mmio_len );
        printf("====================================\n");
        #endif
     }
     if ( gFB >= 0 )  {
        fbi = ioctl( gFB, FBIOGET_VSCREENINFO, &gFBInfo );
        if (fbi >= 0) {
           screen_max_w = (gFBInfo.xres >= screen_max_w)?(gFBInfo.xres):(screen_max_w);
           screen_max_h = (gFBInfo.yres >= screen_max_h)?(gFBInfo.yres):(screen_max_h);
        }
     }
     close(gFB);               

     /* Initialize DirectFB. */
     ret = DirectFBInit( &argc, &argv );
     if (ret) {
          D_DERROR( ret, "DFBTest: DirectFBInit() failed!\n" );
          return ret;
     }

     /* Parse arguments. */
     if (argc != 2) {
        printf("##########################################################################\n");
        printf("argument input error!...usage: Test2D xxx (xxx is the test count).\n");
        printf("##########################################################################\n");
        exit(1);
     }
     else
     {
        const char *arg = argv[1];
        
        gLoopNum = atoi(arg);
           
        if (gLoopNum <= 0) {
           printf("Count number can't set <= 0, force fix to 1000.\n");
           gLoopNum = 1000;
        }
           
        printf( "[Test Count set to: %d]\n", gLoopNum );
     }

     /* Create super interface. */
     ret = DirectFBCreate( &dfb );
     if (ret) {
          D_DERROR( ret, "DFBTest: DirectFBCreate() failed!\n" );
          return ret;
     }
     
     dfb->SetCooperativeLevel(dfb, DFSCL_FULLSCREEN);
     
     dsc.width  = screen_max_w;
     dsc.height = screen_max_h;
     dsc.pixelformat = DSPF_RGB16;
     dsc.flags  = DSDESC_CAPS | DSDESC_PIXELFORMAT;
     dsc.caps   = DSCAPS_PRIMARY;
     
     dfb->CreateSurface(dfb, &dsc, &dest);
     dest->GetSize(dest, &win_w, &win_h);
     printf( "[Test window size ---> width %d, height %d ]\n", win_w, win_h );
     
     dest->Clear( dest, 0x0, 0x0, 0x0, 0xff ); //clean black
     dest->Flip( dest, NULL, DSFLIP_NONE);
     printf( "[DFBTest: Destination is %dx%d using %s\n",
             win_w, win_h, dfb_pixelformat_name(dsc.pixelformat) );  
             
     IDirectFBSurface *logo;
     IDirectFBImageProvider *logo_provider;

     dfb->CreateImageProvider(dfb, "/mnt/mtd/320x240_01.jpg", &logo_provider);
     logo_provider->GetSurfaceDescription(logo_provider, &descImg);
     dfb->CreateSurface( dfb, &descImg, &logo);
     logo_provider->RenderTo(logo_provider, logo, NULL);
     logo_provider->Release(logo_provider);
     system("echo 1 > /proc/flcd200/pip/pip_mode");
     system("echo 200 255 0 2 1 > /proc/flcd200/pip/blend");
     
     double  msT;
     unsigned long long start_utime, end_utime;
     
     // Set default unit size for fill rectangle test
     int rect_w = 320;
     int rect_h = 240;
     
     while (1)
     {
        int x1, y1;
        printf( "==================================================================\n" );
        printf( "Start to TEST!\n" );
        printf( "==================================================================\n" );
        
        dest->Clear ( dest, 0, 0, 0, 0 );
        dest->Flip( dest, NULL, DSFLIP_NONE);
     
        /* Test for Fill Rectangle */
        gettimeofday(&tv,NULL);
        start_utime = tv.tv_sec * 1000000 + tv.tv_usec;
     
        for (i = 0; i < gLoopNum; i++)
        {
           x1 = (rand() % (win_w - rect_w - 20));
           y1 = (rand() % (win_h - rect_h - 20));
               
           dest->SetColor( dest, rand()%256, rand()%256, rand()%256, rand()%256 );
           dest->FillRectangle( dest, x1, y1, rect_w, rect_h );
           
           DFBRegion region = {x1, y1, x1+rect_w-1, y1+rect_h-1};
           dest->Flip( dest, &region, DSFLIP_NONE);
        }

        gettimeofday(&tv2,NULL);
        end_utime = tv2.tv_sec * 1000000 + tv2.tv_usec;
        msT = (double)((end_utime - start_utime) / 1000L);
        printf( "==================================================================\n" );
        printf( "[TEST %d FillRect] Total cost time: %.1f(ms)\n", gLoopNum, msT );
        printf( "==================================================================\n" );

        /* Test for Source Image Blit */
        gettimeofday(&tv,NULL);
        start_utime = tv.tv_sec * 1000000 + tv.tv_usec;
          
        for (i = 0; i < gLoopNum; i++)
        {
           x1 = (rand() % (win_w - rect_w - 20));
           y1 = (rand() % (win_h - rect_h - 20));
           dest->Blit( dest, logo, NULL, x1, y1 );
           DFBRegion region = {x1, y1, x1+rect_w-1, y1+rect_h-1};
           dest->Flip( dest, &region, DSFLIP_NONE);
        }

        gettimeofday(&tv2,NULL);
        end_utime = tv2.tv_sec * 1000000 + tv2.tv_usec;
        msT = (double)((end_utime - start_utime) / 1000L);
        printf( "==================================================================\n" );
        printf( "[TEST %d SrcBlit] Total cost time: %.1f(ms)\n", gLoopNum, msT );
        printf( "==================================================================\n" );
        break;
     }//end while
     
     dest->Clear ( dest, 0, 0, 0, 0 );
     dest->Flip( dest, NULL, DSFLIP_NONE);

     if (dest)  dest->Release( dest );

     /* Shutdown DirectFB. */
     dfb->Release( dfb );

     return ret;
}

